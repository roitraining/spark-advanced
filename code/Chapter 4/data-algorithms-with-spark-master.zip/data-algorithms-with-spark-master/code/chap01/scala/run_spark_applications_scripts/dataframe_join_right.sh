#!/bin/bash
./gradlew clean run -PmainClass=org.data.algorithms.spark.ch01.DataframeJoinRight
