#!/bin/bash
./gradlew clean run -PmainClass=org.data.algorithms.spark.ch03.MapValuesTransformation1
