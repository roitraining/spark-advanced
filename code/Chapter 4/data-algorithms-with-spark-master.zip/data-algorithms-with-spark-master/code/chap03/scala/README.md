The Src contains the following Scala solutions.\
To Run them change your directory to `/book/data-algorithms-with-spark/code/chap03/scala` and run the below scripts
1. FlatMapTransformation1FromFile
```shell
./run_spark_applications_scripts/flat_map_transformation_1_from_file.sh
```
2. FlatmapTransformation1FromCollection
```shell
./run_spark_applications_scripts/flatmap_transformation_1_from_collection.sh
```
3. MapPartitionsTransformation1
```shell
./run_spark_applications_scripts/map_partitions_transformation_1.sh
```
4. MapTransformation1FromCollection
```shell
./run_spark_applications_scripts/map_transformation_1_from_collection.sh
```
5. MapTransformation1FromFile
```shell
./run_spark_applications_scripts/map_transformation_1_from_file.sh
```
6. MapValuesTransformation1
```shell
./run_spark_applications_scripts/map_values_transformation_1.sh
```
7. MapValuesTransformation2
```shell
./run_spark_applications_scripts/map_values_transformation_2.sh
```
8. MapValuesTransformation3
```shell
./run_spark_applications_scripts/map_values_transformation_3.sh
```
