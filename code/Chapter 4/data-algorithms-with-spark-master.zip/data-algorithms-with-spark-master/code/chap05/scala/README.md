Scala Solutions
