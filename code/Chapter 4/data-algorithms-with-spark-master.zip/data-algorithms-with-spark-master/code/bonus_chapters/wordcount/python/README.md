````
The purpose of this folder is to present 
multiple solutions for classic word count 
problem.

Solutions are provided by using reduceByKey()
and groupByKey() reducers. In general, solution
by using reduceByKey() is a scale-out solution
than using groupByKey().


best regards,
Mahmoud Parsian
````
