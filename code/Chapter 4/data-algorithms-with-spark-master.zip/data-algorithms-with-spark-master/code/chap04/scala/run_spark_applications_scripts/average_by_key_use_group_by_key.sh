#!/bin/bash
./gradlew clean run -PmainClass=org.data.algorithms.spark.ch04.AverageByKeyUseGroupByKey
